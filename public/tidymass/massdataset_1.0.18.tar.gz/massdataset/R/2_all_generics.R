setGeneric(
  name = "sample_info",
  def = function(object, ...)
    standardGeneric("sample_info")
)

setGeneric(
  name = "expression_data",
  def = function(object, ...)
    standardGeneric(f = "expression_data")
)

setGeneric(
  name = "variable_info",
  def = function(object, ...)
    standardGeneric(f = "variable_info")
)

setGeneric(
  name = "process_info",
  def = function(object, ...)
    standardGeneric(f = "process_info")
)

setGeneric(
  name = "ms2_data",
  def = function(object, ...)
    standardGeneric(f = "ms2_data")
)

setGeneric(
  name = "sample_info_note",
  def = function(object, ...)
    standardGeneric(f = "sample_info_note")
)

setGeneric(
  name = "variable_info_note",
  def = function(object, ...)
    standardGeneric(f = "variable_info_note")
)

setGeneric(
  name = "annotation_table",
  def = function(object, ...)
    standardGeneric(f = "annotation_table")
)

