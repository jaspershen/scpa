## ---- include = FALSE, echo=FALSE---------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = TRUE,
  out.width = "100%"
)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE, cache=TRUE---------
sessionInfo()

