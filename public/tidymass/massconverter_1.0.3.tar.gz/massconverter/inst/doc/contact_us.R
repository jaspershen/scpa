## ---- include = FALSE, echo=FALSE---------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  # fig.width = 7, 
  # fig.height = 5,
  warning = FALSE,
  message = TRUE
)

## ---- echo=FALSE--------------------------------------------------------------
# set seed for reproducible widget id
if (requireNamespace("htmltools", quietly = TRUE)) {
  htmlwidgets::setWidgetIdSeed(42)
}
library(leaflet)
leaflet::leaflet(width = "100%") %>%
  addTiles() %>%
  addMarkers(
    lng = -122.174878,
    lat = 37.432402,
    popup = "Stanford Medicine"
  )

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE, cache=TRUE---------
sessionInfo()

