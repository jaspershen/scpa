## ---- include = FALSE, echo=FALSE---------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = TRUE,
  out.width = "100%"
)

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE, cache=TRUE--------
#  remotes::install_gitlab("tidymass/massconverter", dependencies = TRUE)

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE, cache=TRUE--------
#  remotes::install_github("tidymass/massconverter", dependencies = TRUE)

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE, cache=TRUE--------
#  usethis::create_github_token()

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE, cache=TRUE--------
#  usethis::edit_r_environ()

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE, cache=TRUE--------
#  install.packages("raster")

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE, cache=TRUE--------
#  install.packages("Cairo")

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE, cache=TRUE---------
sessionInfo()

