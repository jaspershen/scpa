library(testthat)
library(massconverter)

test_check("massconverter")
